import React from "react";

function App() {
  const movies = [
    {
      title: "Eeswar",
      year: 2002,
      role: "Eeswar",
      img: "https://assets-in.bmscdn.com/discovery-catalog/events/et00415727-wqdswbnlnj-landscape.jpg",
    },
    {
      title: "Raghavendra",
      year: 2003,
      role: "Raghavendra",
      img: "https://i.ytimg.com/vi/akGNsr87Mhw/maxresdefault.jpg",
    },
    {
      title: "Varsham",
      year: 2004,
      role: "Venkat",
      img: "https://m.media-amazon.com/images/M/MV5BZWRhNDYwYjEtYzgwYS00MDE0LTlmMjgtYzU5MWE2MzM5ODUxXkEyXkFqcGc@._V1_.jpg",
    },
    {
      title: "Adavi Ramudu",
      year: 2004,
      role: "Ramu",
      img: "https://upload.wikimedia.org/wikipedia/en/8/8f/Adavi_Ramudu.jpg",
    },
    {
      title: "Chakram",
      year: 2005,
      role: "Chakram",
      img: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExMWFhUXGBsZGBgYGB0YHRoYGBgbGh0bGiAdHyggGholIBgdITEhJSkrLi4uGB8zODMtNygtLisBCgoKDg0OGxAQGy8lICUtLS8yKzA2LS0tLS0tLS0tLS0tLS8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAQ4AuwMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAAEBQMGBwIBAAj/xABAEAABAwIDBAgDCAIBAwQDAAABAgMRACEEEjEFQVFhBhMicYGRofAyscEHFCNCUtHh8WJyMySCkhVDotI0Y7L/xAAbAQACAwEBAQAAAAAAAAAAAAADBAIFBgEAB//EADMRAAICAQQABQIFAwQDAQAAAAECAAMRBBIhMQUTIkFRYXEjMoGRsRSh0QbB4fAkM0IV/9oADAMBAAIRAxEAPwDPwIN1SOZ3VIh8AW9+dCqeE/xUYdBMEgd9WGQp4lTtLdw4Yr3NepxQNJzir1IjEVwXTvkRkpGa4IBr5tlVzw50vDyTrTHB4xIEX4CvLsY5M6Q6icBsrMQOFGlJGW0c+fD2KHaxDeYk24318qZhaJB37rk8h30RFXvMg5PWJLgcanMEGJ3/ALH3wpsxg0gzfiQY+ugFLMO4mZATm36evA07bWD7+dNocjmJ2jHU4U2CCAQLbjMHcfZ+tLxgwAS4pJG/W4ERv18OFNlxvj379ahS4kk2v3HUDu93qZAPcgpI6jLBN5W05QRYa66DyFzpXubjqb3M246US0UlKdPhG/l79ajWOEfz7+VYG8fiN9z/ADPpOmb8NfsP4i91xJB0nS/ERr73d9J8Zs/MSpJSCdR6eHvjVgcaHjGuvn5UBiNnoJJM8xui/KPZqFbYMcyCMGV9eHWkEmAJ0m3rVbxO0DmkAVaemGK6vDpy/nUESeAzH6etZup3X96stMhYbjKbxHUbW8tPaPhthWYWGlFsdICTEJ8qqfWGukOkUc0KfaJLrLl/+pcmsd3X8f5qUPlfZTryuaqzWMrQej+BdQ0nsJlyCTnAMESNb+FBatVOWOIca20qQgyf2iASJzeI+VH4doFIN/MUdi9kr7aikAC/xAwJFzBPHhwoPDiEi3H51EsM8HMYqYlAXGP7yrOrgmDUOFaU6vInU19tBsgBQMg8N1NuizgbhWRS1qNkoGZRHcN1WlzYmeqTIzHOyehSlRmJNH4zoD2ezarh0SxS3lZFsusxF3BHv+alxmGxKnVo61htIJAMKWSN0wRflaky7GNBBMN2rg3MOspVzg8RQLOIUTa9aH062atKD1mRZSf+RuRrNlJVdPeCdd1UrYGAW4HCJATEmPSiLZ6cmeNfOAJMhhzslSTrbSPGnezUt5CpeoN7xF7EedT7CUpXaKkvIHxIylKo3lMalOsb4p3t7ZQDPWMIQTqSBcjjXU1GDiDs0+RK9h3u2cpEfqBmfSIp/hFmPi8BH7VTtkIdWSUoUqNSBYGbSdBe2u8Vaercb/5G1oniOPPf51aUW5lbfUR1HCZ4/P8AqvsOzE9okHSb+u8d/Gg8NiAZtprPpXGOxgAhPjT24AZiG05xHmI2mhtKe0SQlMgdw3xAqu4rpiUghKRHE38aT7TxVgNwA9x79KqmNxJVPAVkxp1ZyT8ma86pwgVT7CWzE9N3fykDuAPzFCsdN30qOaCOECR4gVUkuQamwWDU6vKnU0XyawOoEai4n8xjjpX0j+9JbABTlKiRNiTABA3b/Oq3NWbG9CcShGdKc4iba+HGgNg4NK1KCxpaK6joF9PQkmSx39XZkex9m9abyBpI+tHvdG1grSEkmRk98Ks2wMChlHajU3MCngxzI+FaVK4JIJ9KTs1TBjt6j1eiTbh+5m2P6NYhpGdaRHK8VL0b2jiEq6ppxaUnUBShHMQbVpikhxJSoSDVNZ2WcJi0HVtw5f8AWTapV6repB7grtGEYfHvDhjV5silLX/ssm//AHHTuohkmBBtRONwwCgToNJ0vQyeXy/mgB95zLZVCLgdSn4VtCpC5gmLd1vWnPR195pIGHbzkqOZRtZJgAwDaBSHDtEqPDmd+laL9lmHAcCFwrKTPA3n331b3kiZWkQ/ZiMU463nspRkISCISIm5vw3Cido7EeceKW3XGlpVNovPCQbjlRe39pkYlC+u6qDZIiQJ00sONePbQw7LsqdWrOJJzKWApX6YskzwAqsJYneJaInpxiKcZ0DeQCl15xxTsJvAAzG5trTHbezWMPhkMMlIgRI3nnzNPumr7itmLcvnQ0oiJBlE3tcaTFZtsZx7EYZBWsqCSbmc3+pMyY58a6zZUkmerAJAnnRnZRKyqDmgCxt2RExx/em3THbP3DDhIEuOSEDcAPiUeQkW4nlTHYTqUd5qpfa6hbzuHKEqXCFiEpKohSSTa/5gPCuUMbLMtI3gKuFlS2bgsXjFDqk5sht8KEpJ4Cw8vGtO6O/ZljXv/wAnEJbA0U12iSeNgALaD9zVW+yzAz1yxPWphKQZATInMRv8eFXZeBxGHeRisbiVfdgCFNocchWZJFwk8L2AvGlN+eRYVz1B/wBKDUGxyZWcXh1YZx1lchaFFJm0wbK7iO0ORFLcW6I9/v4VZemmyEobYfafLzKwpAUqCoEEqSkkC8JMXk9kiqTiSrj7vVwtu6vMobKtthEF2hiBl8I9PWq6s0y2i9IA5UrVVcBLOeoBJAGp0rWvs+6H5Uhxycx3DcOFU3oDsfrncx0SQK2PFNNNoT1hUE8AooT4xE+JpLU3c7BHtNVxvP6RkvCDKU1jvSvAjDYtSwLLExzFWvbuz2wQcOpbK1GQW1kCeaQYPjSnpUx16mWHcxcVHaQkHtBJM3gAGgV4DjHv3GWDbc/tKg5tJThCnB2BojjG88aebJxgdiBA0CQI01/apGtgBKAhfxIJBPMb6kw2HQyQQKlZYhGFEJTTYGDMZcsCwAm9K9tYYLGUyJ0PA1IjagUnWgnn5Mz40nWCDGLBnuSYYHIAu6kzc0KRXv3i3GoetmjKpzmDD4GJUVNdmItqSatexsenDMpxaWnElbgSns/hKA17UyDE7otVSxCyARUmB2otaC2oFUXkJFgIAJI3zv7r1f3r7TLUkzaPu+Hxi28UkAFQGaLKBTYgxBtbzp/jdlJhDiu0UxE7r7uFZR0T2utCkqQMxEgomJH7296h10g+1MpSWy2UnSFA27tx86qmrPI+ZaraQBLH0x6QtJwzrRklTapgGAVAgSQLAmsx2A+lCFDMcpOYcBIHrQeJ2q9iWnFJ/PMgCdLeFvnVfb22pIAFotfdFSSglcGca3acrNFbxiZseYr3H44ITmIzQDO8lJEGB3GY3wBuEUfB7XUr4Qk+PGiVOvqtx98K95AE4tzbt3vLxsFpOUYlKpSWk33uIzlOa03SoEGY+KiMfimsTkaW7kSFTCvgUR8OblSjB4VbeCZSpKkkOPCIggKCFRG4ElRqXYeyEPOhC1KA15nlfTWlXASzOZeUr5lG8j6yy9OA0nAtIC21LU6CAgkgJShQPxEx8Q86y3GwJg1rfSLoSpSW1YVuQEFKk5oMhRIIB1kH051m3SLZbrP/ACtKRIsVJgHuVofA7qvqGHkj5mR1YPnkjqUrHGgqZY1u4J9wKI2DhkrXBGnrSxYKCY1WpYhRLp9mODWlOa9zJHKtXfwTbzZacEpUIPjVd6M4QIQmKeYh4jSqdrNzFpdKm1Qsq7HQBLDwWh5amrwlR0/enL2xW+sD9+sSjJyidRz1HjXuGxS3Z7QAHE7xQWI2ji0vIaBYCDqMpKjxgzHoamPXyZwLjgSsbbW4y45KFKCgCgxIMJAieMiIqkYjbzpcgwpQtP5RxAHI1tL+YpypMOHTsi58fnrVP2p0TsVNJSy6CSYE5jMm5EpJ1BBt3XolTID6hOXm0qNhlN2e9iAslRlAPatHl3U1dxs6UvYxBQA2eHnxP810kjS8Rut8qMyZbqL+aVXGcxkXYTz3Vy2u2k0vGJkxbhRrTogVDaVhkO4QBvZuc3MUvfwhbdhJUAYB59/GnmHcANdvYfM5m10JrSXUbupk6r8dyDCEpISj47RunvG41Zds9UA22ptRUpIzhxspjumyxzH1peTcKATMg3Em0a+VMsRjSuCsBRHEzblJ9KSGmODGjqgCIrweyRh152v+NfxINwJ3pPD5VVul+xi2rrUiyj2hzO8d/wA60ZpYyi1o0j35U0wjLbTQfWnO5bqgbhMSQoj9XDhS96igb2jemY6lwiSk9D/s1xBAxOKV93ZiQkiXVTp2fyTxVflVrU4hlQS0gBAImbqVBFyTvsDa3KvntvOKEKM+vzoNxcjvqju1TWHjiavReFirmwZhGM2alTmdok5kzfjN9/MVNsvCvNrB6s3MA8DQmBximlAi4uIOl/leKdI6SjKBl3jwNROH5Jh2S2oFFGRL7srFZGypZgAR3n39aWp2ncyJCjoYIOpuDVWVtZTmUEnKNBwkzJHGjV4gEWMQI5iR7Hj30yb+gvtKU6QgksO4PtnotszFznZDSzotg5Lk65fgPiKzraHRJzAvZSoKSboWNFp48lDQj6RVqxOIyq13Aj/yg/Wnm02k4nBAn/ka7Q7j8SfkfCvLqSwKmEfQikrZ7RRsTaQSkA02xO1UrSopUIRYm5jyvVQwePLCwpKCsgG0bt5pVitppfUrMnUn4SQoX04250NKt3MLZgGWpGGwsqWG0rUqSQCQcxAuIIO7TvqXAMsKezNdYABdC1E5SeEiSk6XqqKwDjfbZX1g/Sowodx0V6VLgduu/EUrABglSTY8Cd1G524HIkQAOOjL0+4FAhE5k3BuQDfw7++q67tpZcJcuRAI00n/AOVzf6UdhtvpIg2m97jX0rrHYXDPtyVFt+TDo7SFcErSLjvFxz0oaDPEk3oGSIH0l6CpxpS/s5xAKh+KhwlPb3qmCQTvGlpG+uOj/QINn/qVBxZHwpnIkmQDxUfADkaW7I2u60q2ZpYkXkT3HRSavXR7Hl4ZzrmCT4fvNPV2g+kjmVd2nK+sHImX9NNjKw2VwJ7MwYHvh60DhcWkpEGtc6dbPS5hnBEkJJAtuuPUVjTWHgATUuDxOVl16jBMyIgzT3CsWACRpwH80rwjSSqYvVmwIEa+9fr8q1RXjJmRZsGDNoPIgC/frwtp61CB2spME6JBgzvgkbo/enyWrDjz5/I1GtgAQT77h3eQ8hAid3ZifD4RDi0hWcIRdd4BAOnMqMC14PKj9qYwqCJN5kxpJANvOpcSUhACdSbnkNO+5M0oxjlyec+FZLxe/wAy/YOl/mfQv9NaIJpxcw5bn9Pacqd07/pUgcoDPcf7fSiFGq1kxNMjBswyZEbqicXvjXhx3/v4iuEu1O+ix/TfKdxJgEi0nQCb6TuqdSZBPxF77QjquO58xiSKMRjFcaUtjdReFBnSbUM8SdlSEZxPNpL+Gd5M92vz+dO9hPnOhuxzBcjvST8z6VWtrPw4lP6RMd5t8qabGxGV0Kn4Ekzzg/U1LoAxexA9TD4zBMa0tp1QQSCLCOBv8oqu4zBdYoqUNDJUISZJ96VfOkjQ6wFOi0JWPKI9KB2U4240puEOKKzYglKNQFOnSw3a3MCYKW6ckkCUd1qqgLDMpzmIW3vK07jbN/NNNl7QAEzfy8CDu5G1N8V0SQpwNslSVZCtee4FwlAI/Kpd1ESYg1Xto7NU2crzcEaKHzB4URwOveeps3cj9j/mdrwxzFSVm5nLAgchAEDlXbTi9DahUyBAUTwPL612CfzVA/WGwB1DV4js5VQe+9NejG0ercAnsqIHjuPvjSMKJtXqLGKiCRzOOgYYM0naGP6xBtbQ3BgjdFZTi8MpK1CN51IH1q4NvlDairgMwvOk0ld6tRJgGamtpDExYUjEAwaiSd0VY8E6qBEd3D60gwDV+dWXDoASLT32tf3zrcNwvMwLHmFJWYvz4V0ViNahaw8C5tzv4CpFMJ1PzigcT2INtZEBBkGUzYzEk2PCkby9aa7TQJGX8qQCb7hod1qTrQoqArE2/i6lvqZ9Y0GKNAn0UT1iChQvmse6DH1roiul4ZQUCCVC8zrf051ytUU14np/JsVR8RbwDWHVV2O3e4/8T5R3CimkgDdQjYoptVVbfSXuM8z5Yg0fgkXmgHRvpls9Wl/f1qJgb8hIu6QYZCcjgPbJIjikaHlB85ofAYix4mmfSRlPUpVoQsiYsQr+qR4JsnQSPD96OFzWIDTuMkS5YxoLaw6jr1ZFuSiPrSjZuwghZX1q2zmJsQbE3HaSY13EA2qwbPSFtIAJBRmBBHGDa/fXT7JTfUC5MQMsX9KkjsOpS3KpJDexMnaQhCCEJtc2JKlm1ySZJ1kzNAJwyFBaVTlUbJXFtbjUiT/FQ7P6TYdWUBYTN/xBli1otv8AfCnCHM10wq0yCCPPdp73zdXHJEDXYnSmUzGdGl5lFkKUkDMRaw5fqpOWyO+tY2UFArsIgazOt/kKD2rsxtySWxm1J0O69tf7roPpBhVvAbBEzRJVoAOdONl4K/WESAdOY39wo3H7ICRKSdLg6e7fWgsQFIiDAG7Xd68ajuz1GDgjicbWeVGUbzJ3i3zv8qTpSR7FEOLJKsyp8dPf0oXPzHnRUGJ5lGBCNnm+tWVhIMT79/vVb2akTVgaWQUwoHlFo+fvvrdWdCfMyOYe1axB04cPcfvpUby4Oh8t9Smw1+lQlxJMZr8P297r0sO572irabiyoAWTEAi9gBM8+/h3UJiWSlSSlU6ax3bhTh0pggkwoQZEwdZ79NOdAITmTl0Wk27xWY12n/p7w3sTmbrwzXnU6bYOCoxj/vzBVKXJN9I4a+zUSgd9SPCbSRx999DkqG/MPWo+K2i2/wBJ6All/p6g06QbxjJJkgNTtKoUOg8QamTMWFVbCaAHMJJFF4FXv2aAQDF6KwZiLUMyNi5WE7VZ6xlcK7Tap3/DlE7on9qQbOS6ogJQFzum/qP2p1i8SE4XFGwISkA/7kI31H0QSQsWMf1TKDFWcSlstZLWUHGOZa+jwJbukpgqBC9QRwO8eFD9MXgjCOx8Sobj/dUHS5tPlT0k8J5E/Oqh09cUvqEBIIBLtyREJyp045leXM0ehNzgSp1Nh2s0V7E2IhaQtyY/KEkgQLSrNcaG1F7a2Mltsrw6ihae0RmIkDUiNCKk2Xi+sQmcqVpOUpBi3EcRHIfKvNr4zq0wpQCiDl0mYgGxuPCr41147lHk5hfQHaDriXi6slKcoTMG5km+/wDLrxqwYp43Ph8x5THhSTocz1eERuKypZ0veAbf4gUTisQAfdpO6N/u1qz+of1kCXulrOwZgWMxZMzxvbXhr8qQYtcbjy4Tz50ZjZUScxAvrAjuHCw1v6UqxoIt85vQkXmW6DauYKpSRP8Afs0MX0jjXsmPHQf37vQSlKH6ffjTSpAW24xxGmzlCdDrzqwsvAR2Z7t2tVrBK7XxXO+nuDbk8rXOnz+lbY/lnzdl5jdrEQY5TqPlymvlmTJjf79TQxTIlQAOg4+lorkqJ1teBJgeHA238RQtokZMvu8ff90vxLRBzjx7x8+HhUeKfKVGcscQZi+8e9eVF7FwicQtDSSVBRAUpM2uJPAa+tJ6/Ti6kj3HMsvDNQdPeG9jwZ8dhvKh5LSyhz4Sm5zASqw3WN+RoDEYfUEaWO4g8ORresFhENpCW0BKdfSPkKV7d6J4fEErKcrh/OmxJ58azdmiJGVPM2Wk8a2HbYvp+kwtbJ5/Ou2MwOtW/bHQrFNHsILqeKInyn9qr72ysQkytp1MHUtqA84j1pRksHBEvKtXprOVYTnNO6u2xvrgNxrbvtUrKM1kdo8E9r5UuVMaZ0x3F223OwEDR1Ynnk7XzAq09E8MBKoi1p/j3aqr0sZdZ+7uFsp7aknrUlKYUAqSTEGEmDyNaLsPZriWWyG1AOAKAIgmU5oA46+VOeW4rXiZzUalDbYM88QsueI37t/8bhS/aWzmniC4gk2AIJnKCYi8anfe9E40rQchlCv9SYniPr3mvg3AMme8AaE8I4RUQxU5BwYqVVhzzK8/0VBEpcULfmAOk7+U6gfSk20dgOgfAFbpB38TIndwq9vaXA8+/X50G8kqNzHjrvg+s0wNbaOzn7wB0VTHjieNOpS2lIsEJSnhYCB8qVvnPdKjYi08Bx19imAbI1Mjhr9Ld1AuqSSoCATYz46bh4caSJ5zLKpcdRY+oju4H3O6kGMxJkiBbjvH7+FOdqLypMQTMRcx78Kr2ISYkWm97+E0eoe5jLsdvEgdWRvgeVqhSkcRXD7XFQndXwaPH0ptQJXWMSeRGWzGe1cb/Pxp3hmshufAaiRb+9KA2SL0/Vi2m7OupSdYNyLfpSJNa6x1rUZmESt7WwgJ+0LaFp1J4CuFYMdrWDrJJ8uF6FPSbDaZlHmEEVIjbLCz2HhfcqUX/wC4Ab/Gk11NZPDCMN4dqkGTWf2kLuDbKY0HEG/ceXfxpl0H/AxACYIcKUHiJUDby7tahdY793dui9GdGcGTiW4E9qTePhE/tRrSprOfiL0lhYB9ZrLJOhrl1tW4nzB9D+9A4ZxYMFU8J5DfHu9EsbQmcwiDBynOPS48QKo5fyBzFOJ1CFcrpPrUWE2uVZiUwArLMzuue6beFMcQUKQTZQiRvm26luA2fkQlNwBrHak6k6CuYM7JlKQ5r1Su9M/OpkNBKcoSgA7gi3kKgXhk71A96f3qfCtJ3R4V7E7mIOm2z0PMpzSFhxGUgkRkVnJvpIBSbfmoTpBhXF9S8gGTkv2QAsmEwZ5kcKL6SOFTsC4SI7iYJ7/y+VL3W891ZiQALLWmAN0BQHs0ubwHIPUP5BKDHcC6SNutrbIQpSkpTnCBmUsFSE5M2k9oqMx8E6A0sG0X8pV90VN47Wa4CQnswFZZUbCDAGtwHO0tpNMAde6EnLYXUopECwuoi0SeGtVnG9OWxZphShpK1BPoAqRykVOrTW3/AJKs/Wce9KR6rMfSMk45zOhBZGXQrggZjniAe0JyggKEwTraYvv6ySDh3NJi4m4sCURMEm5AEXNJ19N1n/2W+c5iY33mvGOlyJPWYexGqVX7oIv50ezwnUDnyv7waeI05/8AZ/aGrxCsshGUwCSuTJzgFMqSMsybm1xeRQ6lhSgEtudsrKVFCvgAH4kalJzA2g/lIBKSZsJjMM7HVKharZHABruEkgmdwJqRxhQmwTfS0THDvM1XWHyztevB+ss6gX9VduREmJYzXW2sCLBRntb5tcGRafymQCbLX2QCeHGwBPhT19Cjv9PLXWleKRAjNHd/dBNmTxxLWmsqnqOTE8IMx8o8t9eDDg/3RAsLmfTjUaRyoqkyLoCOpL1qkoWUzmA8hNz5e7V2yhhwkoYdgCVfipnvvrUmAVCqar2Kw5KinJxKFZfQgp9K0fiGkssIdT+kx/hXiVOnUo4I+o/3i9eyEgf8DhISBKXERnIsbmY5C1QOYVtKQtbDiU2PZWNJSIgqJG+ZvJFqMX0cb16xf/jPyqXDdH2ZElauMyAb7oAPrv8AOtGhuJ/LLn/9jSqM+YT9gf8AM52BiZzhAWGgkRmMwuLgHgRJj96tvRjGrbxLWQJJWsIOYEQlRGYpg/FHHnSsIASEpygDQCB6DU8/GjujeX72ySYIWIAvJPZ8LKJvwqzFRr05UnJmbu1SX6sWKMD/AL39ZpGI2esrCgoQDpBOv/cPOjEMCxUi43kA+W8VKHNLTUjSp/qKrMSxlT6b4r7sllSTCXHsq77si15hzlN41E046krQHGjci8aH+ar/ANqjMt4ZWaAl+SOJLTgHlJNEdB9oSjqVG6fhvu3e+VDLAPt+ZMD05jBvHKmFWI42plhHZJTF0xJ3Xv56eYqPG4IG8THgfPQ+NKtt4hzD4LEOtmXI7BKZKSohAJFxCRBnSxJtRADmQMBxaJcWSZOZV+EEi3lVQ6X9InGHEsNIKFKTm60gEEX7LeoKhNydOe59s9leKUGWlHIkJL7gtciUtDhI7RjcR+qam6X9F0FoM/lVZlWqmnACoACLtmCf8YjSIDTWqWeY4yAeoa2wvXsQ4OO5kbkklSiSSblRJJPebk072f0RxjwlLOQbi6ernuEFe7emmIfw+zyUIjEYxI7TihCWpmMqZMHuM8SLCk+0ttvPkl11Sp/LMJHckWrV13Xagf8AjgKnyf8AYTPvXXSfxiS3wP8AMNd6HupscRhQr9Oc8Y4fShMX0XxaE5iyFp4tKz+hANLQoC1qlwuOW0cza1IP+JjzjXxqZo1Y5W0H6ESPnUHg1kfrAFAXG8agiCO8HSn/AEU2q+tRbIzsoF1q1QYMJSfzT+k7uGh5++Jx6ksvNnrNQ80AlWVIk5x8JnSYAkixq69GOj4UBhmgUtNn8ZzeSR8IOhcUIJI+FJGnZql8U1fmL5DoN/8Ab7iW2go8s+cren+/2lYxRzaQRvI1ETa2+efGleLQDP8AMftWm9NejaWm+vYQlKUgJcQLAJAgODgU2B/xufhrMNptrCz/AH4VnHpNbYms0mqFq59/iKn1ATuqNly3nv5148oibiP7oRs20PnTCLxA33EGNsKsjcTT/BPExKdOJNj8vrVcwiJNWPAj5WG73+1bLGVnztjgw5OLBMdrhOvh329agfxWUzc8h+2/WvEjtEk98xu425Vy64CMsJUZI4d/ha9DA5nPtO04kEBVyCJ8+73rUuzsd1TqHcphC0rO+yTeOJgUIlMJiAP315c68ZSnMEwQCRJ7+/So3VlqyBDad1W0E9Zm3N4gLghWUmDaDNEo1vB50iwOz0EZUthTYgDMYSUjlvGm6DrwJeYdvKIhIHBNUEv5S/tPaK/u4k2K1eIyj5E+ZpLst4tKSsbvlVl6VupeyFIPYUtJzJIuCkHXUcxakSsOIpS0HfmFU8Ymg4Z8LQFpNVf7R9odUwNIGZxfZzEpQIASNMxUtMG+kRejuiuKAaXmMdXck/piZNU/bj7OOWpaklSFpSGwQe22klSCnKZglWaRe4nQU5V68HMBcdo6zL90V2WcPhkNqguHtukb3V3V4A9kckgUu2+0oOLW6OxlCUL1ShMSrPvQSq5V8MJSJB1R7OL2HSOqxa4AA6vEpUtOYxYFWVY1gdo91N2Ol6kQMTh1D/8AYyetRHEiyx4A660NirZUwigjBEp3TTox1o65oQ+gW/zTbsH5gc6qHRf7s4+lOJCsh7IGfIErn/3IvG6xA4ggyNfSzh3wVYJ1tZTcs5rJP+I+JlXhHISTWZdOdgLzLfbayOC7zRieAUACZBO8WNxfczo9Q1QNDE7W6PwYPUVLYRao9Q9vmWTE7IwQOU4ViP8AQT8pJ8/2rO2OjjSu1hCQq34Zui57+z4cKO6Hba+8Npw7phwD8NUntpAmJmcwA8QORp2zgiVBDfadWYSASNNVr4NpkSe4C5FVztqtNftDHP8AMsUXS3U7mAkHRPYGWGm4L64U64PhbRcAwRuuEjVSpNhMXvFY1nAMhppOZYBKWwbqJJJWtW6TJKjdRmAo2pW/j0YJpTbH4jsy66RPbiLx8SoAARMJAE6AGi4zHKUuesJUbrKrqUQIKjFtItoMsCwEdsv2kljlj3I0aY28LwomtbP2s3iMMh4CUuIkpN+SkncYMg9xrG+kOGhwpBlKSUidcuomdbEAneQavP2UYkhrEsgEpbeKkf6upCgO6c3rST7R1p68kIylSBmGk5Se1/8AOI5V28bqw0lomNWo2/pM5xCLEAgezS2B+oelF4k3Iv7+lKlOXPv6VCoHEe1bLkcRxhlmadYHEboPoPnSXCi/GmgeCRNbFPy8z5+/fEbOOJAGbTutUDzwTp424TpSl7a9+Xvxrk7Zn4hI4GhC1MyXktGreIC7gnyqz9A9ijEvlSgS23CiDoVE9kRwsSe6qXgscgzAib+laF9mbi1F5tK8qSEqUoXNiRAkECZ15W5Q1Nn4JKwmnrHnAETQ3EqSLTA3AST9BU2HUo/EI4CZPjurxi6QEzl4kySOU3Pef5qJezhnQtJKSkkmPzgpIyq4iSD3pFUUvYl6YtLJbKDBAVzBumxBpVg1hfZUMqtDwmrTtdoKKQeB+lAHAIiVW5ihspzmdBi5eBUlt4AWcacRO6SggHlf51Sui3/T/dkPpdTIQ2ohxC0hWUCQkScsieQPfVu6QYzI2GQSJBKjecm7S4t7iqNtjFhLYcSo5mHW3stwSEKBiDqkg38aar0/4e6KWanFoQTWNrIQMOSk9kKbJPIOIJJ7gJpVhMK67mLbYCQopCnFKQVQASpIyGUmYBndVnYxaC2HZAQU5pJAGWJmdIi80uw3SNpb6WAFjMlSkLUMqV5dQme0bXmIIEiRS7IrHmOK7L1KztHZCVOht1sLeASpHVkhZzFQkKABSkEXVYC2+J7xbOVsYZbinVJUCpZOYtSBDLSj2lEgXKpMKMjtACxbe2nk/DbI61Q1MfhpNsx4kmQlO8zuBqi4rELQcoCcovIWVGSRdRmSSTmO8yTfevc4rGF7jFFZtOT7SldJdlnCPhxslLS1ShY1Q5MxPqP7q2dHOk5/EeUCtKkpbxKUSHGgAQHGim5bNzEyDMGRcxLDWIZLa8q0qkHLpMzInQzvrOHPvGzMWFagWB/K62d2+DbwI5U3p7/6mvy2/OvR+R8QF9Hk2bh+U9j4M1vF7FW4yleFdS+zHYiEqCeAiEr4flI5mqpicAoKKYUCNQZB1sCCJFuNMti7QW0lOLwRzsuXdYJgKOhyT8DoNjuPO1XnBPYTaLQcSAoC36XG1CJSY7SFctDzBpJqFszjgxurVPTx2JX/ALMmiHcaYIksjxCVE/8A9ChftUaAW0qLlC53WCm4+dXTYexk4YOQorLi85KgAfhSkCwAtl4b6z/7S9oBT5TNm0hHco9tXopFEsGynBkdP+JqQR85ma4li5i/rSss91PX1d9+B38t/hS1WbcD/wCJNL1sZdaipTiRt4gJ1NEnaaY3VXHda7aRJtrWm/qX6EwX9OvZjN3EpN48qEDgNhUqsCoCZI4nj+1CqYO4/vQbN3vDJt9jJ02NbJ9kuxlqaLq5CHCDH6kIkAH/ABKiSRvyjcb40kW51+ouifVnB4ctCEFpsgcBkFqDaxC4hqVBbPxG9fV9X1LRuJtv4hSC2oAH4pB0ItRWBxbboECCPynUUJttUqA4D5/1UeESlHaOu4e++g5O6S9pWulqj95c0/Lz/KOUWt51XXUp7SVGc6Ski3wkQeGtHbW2wH3nSgSJgGdyRExzIpKp8fHcwYVlHlI1q7qX0AGUNx/EJHzGuE2qzhcOyw46rFLabRkakQIjKtQuARAgqkiOyJmhcLtpeJdSHlhtYcStlxCQOrWD8F5zJWLdq094AVbb2YVpQ+3mDiUAJCwE9YmJKbW5ileHxCXEyO4pOo4gioeHafTapHQn15P6faPa+7UaZkfHowP1+8tvSza+RS8O2sl1ztPrzHNBtbcFECOzGVIA4VWWNsHDJCRlKJnIoSBH6Ygp7gYm5Bon/wBZZWlLWLQVhNkOps434/nA5mdbmaFxPRMvEqw2JbeTrClBC4PEG44XAqddVOnrNOpTOT+bsH/E4zW32LdS+Bjro/8AMOwfTrDoSf8Ap1pm8ByRPG6aR9JelysWjqwylCBe/bX/AOUDloBpUzfQPHE3YPeFtwe6VU5wnQJSBnxC2mEDVSlZjHokeZqFdXh9Tbwef1MYst1Tjac/xEPQ7aTrKygBZbeISQn4grctA3qG+NUjkKueEUtl/rGHUoxeWVoMBLyL2cSDczorUEmNTSfF9JMLgkqRhEh54jKXlSYBF4kAax2UgJ4zVJGOcLvXZ1daVZs03zcfe61Bu0Z1NhuQbBj39/vCV6jyq/Lb1f7T9DYPpwwvDuOkFDrUBxhR7YWqyUj9QUbJULHlBjLNu7QzmVHMZJUrTtKJUe4SbcBFTrw7jiW3n20Jeyx8IzAGfKR+X/KKAfZVqLciJqhuu3HafaaHQaXb+IPeCXVutx14moEsR7/ijFEpMWvx+lqiBXuPrQQT7SzKg9ytusCdYNdjAkXBip0tSrUa7xTfDM1tEoDmfMWuKiKHHSBlJpau81cl7NCk6XqvYrAFJ09f29/QOorZYWi1Wi/MRu9RNfpH7L8WHNmYYgzkTkPJSCRHyr87DCjl6+x/Ffon7MNmKw+zWELSUqOZZBse2oqE84IpC3qP0dy119QuIxSkzDSlAakRf/UTJNdtYoKAsQTuIgi28UvuEZiTHrJdVluZjui1Vzp3tI4bDQD+K/KU8QmO2rvggD/arw1hhJVESZ75rMen+MQ9tANZhDKQmP8AI9pXoQPCp0VBngr7NiExDsHDwJkj57xTJx5Mi5zRoSNNffh31OygI0MATI9ihXkBSgorSYuOyJGnPQXGnyq3GJRkknMaoxhCEdkEZRv5Take0dksvDOg9S9xF0K39r9/7qwMdpAggwmZhOhFj8UeHfUWLJQm7ZUDqQQIJ0G/2ayRteq4uhwcn+Zt0pS2hUYZ4H8SgPtFokPNlJB+LVBtNlaedSBSSAYBG7Q+VXnB4QKJOUXABQVBaSOaSm3h8qEVsPZzii2gBTgJzFtRQU5VZVTlsk5rAG960Wl/1A+3FqZ+olDqvBEDZrfH0Mq6MWsWDjgHAOLA9FVEtQNzc8SZPmafM7BwUqh1S0BJVZ1ZPZuYhUmAZIEkSJiiGcPg0Zi0llXVkStf4gBIkQpaj3SDEyJkGmD45QoytJz9hF18GuY4No/cynI2GvEH8FBM6r0QO9Rt4CTVi2NsBnD3WQ49a4MJSeCeJ/yPhFNMdtQpZStSrGySgHLA1MxcJFzG4GJvS50qBVKgYMEZYFhvPAR5+lHrvFNReOtqn4l/oPDaa+zuIk+Ncm538/c0vdXexPy/qpnMWCJzTxtxPd40txD3agHdw/rhVQqzRJhRI1rBm/rNQidwHnXeHwupMGDY/wBG1uVSJb4+uvzowwJEkmJ2TfSnGDUeHlS3Ct39/WnDKRGlb2oHufKrCOoxw54/xXm0cClaSbT79zXWFY7MT535UevCpKTc+ca389/hyFBtIzOJweJX+h+xU4jHMtKEozFSx/igFUdxIA8a2vbvSNrCt51SSZDaEglbhG5CRcjnpWY9BXm8NjlrcVEsrCReScySQBvMJPvV/s3byiTipGd8JVcAltsiUNInQXk8Som26l1HpfmXtB9GRCNm/ae0VRiGgynMEznUspMEytJbSUgRBImJBNpItm18anJ2cq5Ha/FSiELBvJN53XG8zas1230sRiutZDIKktqU5iAkkJUgZglSkpPZgEHv5GsX2wpxx5RcEKJFjaBlTAA3DLlA5RQ22sOIZSwODP1lshPZUE5QnRKkudYnTUSbVj2EYUpxTjiwtSlkqJjtGdYjfwqldDOtYczNOqSslSMqF5SqUH4gPiAAUeRANXTDptkgSN1p3cTTmjr7MR1z8ACOg4n/ALu8Tx8vSvAUmRM8rWkSPfOkzzhMrSTG8lNvPXzqNnGZwtORRUEqtIBPZURCvykka8aeKYErl5MuzWEnKqSDAtmtEbxoa5OAaGYmx4km08L230t2YXUII6lS0pbARKgFFwKczAKEEIIShQtIzkboHqPvAzBSV5SAe3+IUrAICEiRKDCTmO8xbUZSyglmOR3NlXfhVHPUKw+DbQ4FpcJEGSYJPjbeOelL9o4N5pYLOZZ/GUghKUJQtw5gHQCULSVRfIkxJJUSZ5U3ipJy3MiI7KE9Yn4cvxdkmIKz2QSBoScW7iVIWQ3qmWwpsHMuEmHLwgSVCZjszPGVVb19EGetsWzsGLcXhHy6EF10todWQ6QorT+A6kLSrMUz+LBAgEpEZYvMzgFKUFKfKloP4SihdoWVkKBWStIJhMKERrImiXX8YJHVpAGbKQnPbLbMUyAc3ISDpeUmJYUR2wkrvcC2pIHlA9bTXtRfaqjkfpOaeqtiQQf1lZxuymz8ROc9YSSmR+IVKJQkqyoUColJEkG6sxANSYvFtmfUb+frF9PobtJp1a8oSOrCp+BRKk5BJSQY3q3g9nT9S/EYV4OKscoIhIuIzI7ZzAzvBTBV8UTahFHsADMPmN13VVZKqfiAdcDISDzP17v3FQvswrQkHlYWPuakLawCckdg5cwGbOUoISsAgABSlJkQDl8VfKSsEmALmNVWAAvGtzOgr3kHPBH7xoa1cZKn9pwlohBGWQTBB51E12QBe3L9xRDCycxKp100A+vDw8ajB/yHvxoOSCRG+HUGLMBe9OsOm49mp8J0adSSD1Ug3OZX/wBaORsBcg/h25q/YVvK7k29z5VZW27qfYVuI3ijRJuAPf8AfGu//TFAXy+Zr5DCswEJggxc+/Z40BiDzOAEdiKMcy5nC0KAUmCDr892tDYfHOJ7DlwBAWkx2YsLcrW4VZk4ZStCJjfb9/fdUL2FyE9lB00tPfbvpa6pLODG6bmTqK+jbODylh5ThZM/hl1QR2pk2gk3sSdYIvSbpr0ZZbxh+7MIU0lLeVKlrIEISINzm/mnadltZysJuCSYOUSOQsfelSKaStdpkpm5kHdfePCg06QDuM264n8oiXYuDaS4VjCdUsjKQh1ZQRmmQkgSYAkTBjS9MVpU3GZVhcb+dxqBerBgtmkgwEjTef2ohWxirUpM357h+m/jNMIUr4EVsZ7eTK4l4kTKSDaANNOWvI1xgFSonLpIJIIPl4cAbVY1bEzJ3AcAT73VCrZwRJsRHjHuPdqILlMEUIh2EnKgBNwLcJj+aKCjlPZvz3z3X48alZbASkCbpA8h6fzXxG7jr3xP1rH2r62+82tLDy1+wnDWgMEWuPEX9K9d3A9xjd70qdbG4GDytuqNTWsnQe/lxqGITMjy1Fl93NElsnfpM21vFRFoqvPhxv6eH8VEiSBgKk27tTPy9aXPA8dTxPDjv368KavtdmZmdPXypVjCQbHv8ifod3ChYjNZzEWKdgmd+7QG8bp4UA8q53jv9+lM38ACZMXnS38zf+KCxuHGny7pqa4zHw3EGQ7CYi0nTy8a9TiDw9+VctYeRqdahSgfqX5xRlUSLvwDP//Z",
    },
    {
      title: "Chatrapathi",
      year: 2005,
      role: "Sivaji",
      img: "https://filmyfocus.com/wp-content/uploads/2023/08/chatrapathi1.png",
    },
    {
      title: "Pournami",
      year: 2006,
      role: "Shiva Keshava",
      img: "https://m.media-amazon.com/images/S/pv-target-images/2024f3340f9c9f615ade696f09a5fdfcf8abb1d22e7fb1902c125e040675a68c.png",
    },
    {
      title: "Yogi",
      year: 2007,
      role: "Eeshwar Chandra Prasad",
      img: "https://pbs.twimg.com/media/Ehsdfg5VgAAIidt?format=jpg&name=large",
    },
    {
      title: "Munna",
      year: 2007,
      role: "Munna",
      img: "https://www.idlebrain.com/images3/wp-1munna800.jpg",
    },
    {
      title: "Bujjigaadu: Made in Chennai",
      year: 2008,
      role: "Bujji",
      img: "https://miro.medium.com/0*qTKobatD6AP5owZh.jpg",
    },
    {
      title: "Billa",
      year: 2009,
      role: "Dual Role; Billa & Ranga",
      img: "https://assets-in.bmscdn.com/discovery-catalog/events/et00002846-qpeueuuwjp-landscape.jpg",
    },
    {
      title: "Ek Niranjan",
      year: 2009,
      role: "Chotu",
      img: "https://m.media-amazon.com/images/M/MV5BM2QwYTMzYjEtOWEwOC00OTBhLTkzNmMtYzg2ZTRmNTMxODUxXkEyXkFqcGc@._V1_.jpg",
    },
    {
      title: "Darling",
      year: 2010,
      role: "Prabhas",
      img: "https://m.media-amazon.com/images/M/MV5BZmQ2YzcwNDAtMWM2NC00MzY0LWE2ZTctNDA3NGY5Yjk2N2Q1XkEyXkFqcGc@._V1_.jpg",
    },
    {
      title: "Mr.Perfect",
      year: 2011,
      role: "Vicky",
      img: "https://preview.redd.it/eiiyt22y6l691.jpg?width=1080&crop=smart&auto=webp&s=de16421843ffb65733b69020baa35982e6df18fa",
    },
    {
      title: "Rebel",
      year: 2012,
      role: "Rishi",
      img: "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg1TM4SU3TGOU5PWjg8NGceZco6m4XqouB61pCgBiZ2Z_lkBOl1BlVChvxplr1NhPjjSQUCdZ_zUwEX8Ed0SxXW-Nt9poxBuxeLxI1AtyGvMQvNPtaPBL3FdhoMq0x6azzp7zyT61syTHW8/s1600/Prabhas+Rebel+Movie+First+Look+Wallpapers+3.jpg",
    },
    {
      title: "Mirchi",
      year: 2013,
      role: "Jai",
      img: "https://files.prokerala.com/movies/pics/800/movie-posters-17333.jpg",
    },
    {
      title: "Baahubali: The Beginning",
      year: 2015,
      role: "Amarendra Baahubali",
      img: "https://m.media-amazon.com/images/M/MV5BMjIwMjIwNDM1OV5BMl5BanBnXkFtZTgwOTk1NzY1NTE@._V1_.jpg",
    },
    {
      title: "Baahubali 2: The Conclusion",
      year: 2017,
      role: "Amarendra / Mahendra Baahubali",
      img: "https://m.media-amazon.com/images/M/MV5BYjAwZWE2NmUtYjFjYy00Y2EyLTg4OTgtNmQ0NTQyY2M0NjE1XkEyXkFqcGc@._V1_.jpg",
    },
    {
      title: "Saaho",
      year: 2019,
      role: "Siddharth Nandan Saaho",
      img: "https://m.media-amazon.com/images/M/MV5BODllODJhNzYtNTE0OC00ZTdmLWE3NWQtNGNkM2JjMWZhM2MwXkEyXkFqcGc@._V1_.jpg",
    },
    {
      title: "Radhe Shyam",
      year: 2022,
      role: "Vikram Aditya",
      img: "https://m.media-amazon.com/images/M/MV5BNGE3MmVlYmItZjA5Ny00YzNhLTg0ZGMtNWZhMmUwNjljN2IwXkEyXkFqcGc@._V1_.jpg",
    },
    {
      title: "Adipurush",
      year: 2023,
      role: "Lord Rama",
      img: "https://w0.peakpx.com/wallpaper/815/961/HD-wallpaper-adipurush-bollywood-movie-prabhas.jpg",
    },
    {
      title: "Salaar",
      year: 2023,
      role: "Salaar Devaratha Raisar",
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRDmVnmigDcHhWKVdnhDyS00tiVdXqMhDgRig&s",
    },
    {
      title: "Kalki 2898 AD",
      year: 2024,
      role: "Bhairava",
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcThIIlqOwTWWNAhjXNJsHQdJCOqDxyMeB-wj57ysjq9X9DS6wQ8J0HPbfpLceghlOpzlqY&usqp=CAU",
    },
  ];

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      {/* HERO BANNER */}
      <div
        style={{
          height: "300px",
          backgroundImage:
            "url('https://data1.ibtimes.co.in/en/full/668417/baahubali-2-conclusion.jpg')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "white",
          marginBottom: "20px",
        }}
      >
        <h1
          style={{
            fontSize: "30px",
            fontWeight: "bold",
            backgroundColor: "rgba(0,0,0,0.0)",
            padding: "0px",
            borderRadius: "8px",
            textAlign: "center",
          }}
        >
          Prabhas The Undisputed King
        </h1>
      </div>

      <p style={{ textAlign: "center", marginBottom: "40px" }}>
        Welcome! This website is about Prabhas’s life, career, and achievements.
      </p>

      {/* PERSONAL LIFE */}
      <section>
        <h2>Personal Life</h2>
        <img
          src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fc/Prabhas_at_Baahubali_2_audio_launch.jpg/400px-Prabhas_at_Baahubali_2_audio_launch.jpg"
          alt="Prabhas"
          style={{
            width: "200px",
            float: "left",
            marginRight: "20px",
            marginBottom: "10px",
            borderRadius: "8px",
          }}
        />
        <p>
          Prabhas, born as Uppalapati Venkata Suryanarayana Prabhas Raju on 23
          October 1979 in Chennai, India, is a popular Indian actor. He comes
          from a film family—his father was a film producer. Despite being one
          of the biggest stars, Prabhas is known for his humble and private
          lifestyle.
        </p>
        <div style={{ clear: "both" }}></div>
      </section>

      <hr style={{ margin: "40px 0", borderColor: "#ddd" }} />

      {/* CAREER / FILMOGRAPHY */}
      <section>
        <h2>Career & Filmography</h2>
        <p>Here is a list of Prabhas’s major films and the roles he played:</p>

        <table
          style={{
            width: "100%",
            borderCollapse: "collapse",
            marginTop: "10px",
          }}
        >
          <thead>
            <tr>
              <th style={{ border: "1px solid #ddd", padding: "8px" }}>
                Movie
              </th>
              <th style={{ border: "1px solid #ddd", padding: "8px" }}>Year</th>
              <th style={{ border: "1px solid #ddd", padding: "8px" }}>Role</th>
              <th style={{ border: "1px solid #ddd", padding: "8px" }}>
                Poster
              </th>
            </tr>
          </thead>
          <tbody>
            {movies.map((movie, index) => (
              <tr
                key={index}
                style={{ transition: "background 0.3s" }}
                onMouseEnter={(e) =>
                  (e.currentTarget.style.background = "#f0f0f0")
                }
                onMouseLeave={(e) =>
                  (e.currentTarget.style.background = "white")
                }
              >
                <td style={{ border: "1px solid #ddd", padding: "8px" }}>
                  {movie.title}
                </td>
                <td style={{ border: "1px solid #ddd", padding: "8px" }}>
                  {movie.year}
                </td>
                <td style={{ border: "1px solid #ddd", padding: "8px" }}>
                  {movie.role}
                </td>
                <td
                  style={{
                    border: "1px solid #ddd",
                    padding: "8px",
                    textAlign: "center",
                  }}
                >
                  <img
                    src={movie.img}
                    alt={movie.title}
                    style={{ width: "50px", borderRadius: "4px" }}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <hr style={{ margin: "40px 0", borderColor: "#ddd" }} />

      {/* ACHIEVEMENTS */}
      <section>
        <h2>Achievements</h2>
        <ul>
          <li>Won Nandi Award for Best Actor (Mirchi)</li>
          <li>Wax statue at Madame Tussauds</li>
          <li>Starred in Baahubali 2, one of highest-grossing Indian films</li>
          <li>Recognized as one of the most influential actors in India</li>
        </ul>
      </section>

      <hr style={{ margin: "40px 0", borderColor: "#ddd" }} />

      {/* PHILANTHROPY */}
      <section>
        <h2>Helping Nature & Philanthropy</h2>
        <p>
          Prabhas is known for his generosity and humility. Though he keeps his
          charitable work private, it is known that he has contributed to:
        </p>
        <ul>
          <li>Supporting education for underprivileged children</li>
          <li>Donations to health care initiatives and hospitals</li>
          <li>Helping families affected by natural disasters</li>
          <li>
            Engaging in social causes and encouraging environmental awareness
          </li>
        </ul>
        <p>
          Fans admire him not just for his films but also for his compassionate
          nature and willingness to help those in need.
        </p>
      </section>
    </div>
  );
}

export default App;
